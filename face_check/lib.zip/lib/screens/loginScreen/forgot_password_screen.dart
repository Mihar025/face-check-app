import 'package:flutter/material.dart';

import '../../services/ApiService.dart';

class ForgotPasswordScreen extends StatefulWidget {
  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailController = TextEditingController();
  final _codeController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isLoading = false;
  int _currentStep = 0; // 0 - email, 1 - code, 2 - new password
  String? _email;
  String? _verificationCode;

  // Для переключателей видимости (только UI)
  bool _obscureNew = true;
  bool _obscureConfirm = true;

  // Нейтральные цвета под зелёный фон (как на логине)
  static const Color _sheetBg = Color(0xFFFDFDFC); // тёплый «бумажный» белый
  static const Color _fieldBg = Color(0xFFFAFAFA); // мягкий фон полей

  void _showMessage(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.25,
          ),
        ),
        backgroundColor: isError ? Colors.red : Colors.green,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
        duration: Duration(milliseconds: isError ? 4000 : 500),
      ),
    );
  }

  Future<void> _handleEmailSubmit() async {
    if (_emailController.text.isEmpty) {
      _showMessage('Please enter your email', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      await ApiService.instance.sendEmail(_emailController.text);
      setState(() {
        _email = _emailController.text;
        _currentStep = 1;
      });
      _showMessage('Verification code sent to your email');
    } catch (e) {
      _showMessage(e.toString(), isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _handleCodeVerification() async {
    if (_codeController.text.isEmpty) {
      _showMessage('Please enter verification code', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      await ApiService.instance.verifyCode(_email!, _codeController.text);
      setState(() {
        _currentStep = 2;
        _verificationCode = _codeController.text;
      });
      _showMessage('Code verified successfully');
    } catch (e) {
      _showMessage(e.toString(), isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _handlePasswordReset() async {
    if (_passwordController.text.isEmpty || _confirmPasswordController.text.isEmpty) {
      _showMessage('Please fill all fields', isError: true);
      return;
    }

    if (_passwordController.text != _confirmPasswordController.text) {
      _showMessage('Passwords do not match', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      await ApiService.instance.resetPassword(
        _email!,
        _passwordController.text,
        _confirmPasswordController.text,
        _verificationCode!,
      );

      _showMessage('Password successfully reset');
      await Future.delayed(const Duration(milliseconds: 1000));

      if (mounted && context.mounted) {
        Navigator.of(context).pop();
      }
    } catch (e) {
      _showMessage(e.toString(), isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Унифицированное поле ввода (как на логине): иконки, чёрный текст, ровные бордеры
  Widget _buildInputField({
    required String label,
    required String hint,
    required TextEditingController controller,
    bool isPassword = false,
    TextInputType? keyboardType,
    int? maxLength,
    bool isSmallScreen = false,
    IconData? prefixIcon,
    Widget? suffixIcon,
    bool obscureText = false,
    void Function(String)? onSubmitted,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText || isPassword,
      maxLength: maxLength,
      keyboardType: keyboardType ?? TextInputType.text,
      style: TextStyle(
        color: Colors.black,
        fontSize: isSmallScreen ? 14 : 16,
        fontWeight: FontWeight.w500,
      ),
      decoration: InputDecoration(
        prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,
        suffixIcon: suffixIcon,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.black.withOpacity(0.12),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.black.withOpacity(0.12),
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: Colors.black,
            width: 1.4,
          ),
        ),
        labelText: label,
        labelStyle: TextStyle(
          fontSize: isSmallScreen ? 13 : 15,
          fontWeight: FontWeight.w600,
          color: Colors.black87,
        ),
        hintText: hint,
        hintStyle: TextStyle(
          fontSize: isSmallScreen ? 12 : 14,
          fontWeight: FontWeight.normal,
          color: Colors.black54,
        ),
        filled: true,
        fillColor: _fieldBg,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 14,
          vertical: isSmallScreen ? 12 : 14,
        ),
        counterText: "",
      ),
      onSubmitted: onSubmitted,
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final insets = MediaQuery.of(context).viewInsets.bottom;
    final isSmall = size.width < 360;

    // Локальная тема (как на логине)
    final theme = Theme.of(context).copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: _fieldBg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        labelStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w600),
        hintStyle: const TextStyle(color: Colors.black54),
        prefixIconColor: Colors.black87,
        suffixIconColor: Colors.black87,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.black.withOpacity(0.12), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.black, width: 1.4),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: Colors.black87,
          textStyle: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
    );

    return Theme(
      data: theme,
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Stack(
          fit: StackFit.expand,
          children: [
            const Image(
              image: AssetImage('assets/images/facecheck2.jpg'),
              fit: BoxFit.cover,
            ),
            // лёгкий оверлей для читабельности (без градиентов)
            Container(color: Colors.black.withOpacity(0.18)),
            SafeArea(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  16,
                  size.height * 0.35, // опускаем форму на 35% экрана (как на логине)
                  16,
                  insets > 0 ? insets + 16 : 24,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: _sheetBg,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(24),
                          topRight: Radius.circular(24),
                          bottomLeft: Radius.circular(16),
                          bottomRight: Radius.circular(16),
                        ),
                        border: Border.all(color: Colors.black.withOpacity(0.08)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.14),
                            blurRadius: 26,
                            offset: const Offset(0, 18),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: isSmall ? 14 : 18,
                        vertical: isSmall ? 14 : 18,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // «хэндл» сверху — ощущение системного листа
                          Center(
                            child: Container(
                              width: 44,
                              height: 4.5,
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.18),
                                borderRadius: BorderRadius.circular(99),
                              ),
                            ),
                          ),
                          const Text(
                            'Change Password',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.2,
                            ),
                            textAlign: TextAlign.left,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'We’ll guide you through three quick steps',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 18),

                          // Шаги
                          if (_currentStep == 0) ...[
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 360),
                              child: _buildInputField(
                                label: 'Email',
                                hint: 'Enter your email',
                                controller: _emailController,
                                keyboardType: TextInputType.emailAddress,
                                isSmallScreen: isSmall,
                                prefixIcon: Icons.alternate_email,
                              ),
                            ),
                          ],

                          if (_currentStep == 1) ...[
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 320),
                              child: _buildInputField(
                                label: 'Verification Code',
                                hint: 'Enter 6-digit code',
                                controller: _codeController,
                                keyboardType: TextInputType.number,
                                maxLength: 6,
                                isSmallScreen: isSmall,
                                prefixIcon: Icons.pin_outlined,
                              ),
                            ),
                          ],

                          if (_currentStep == 2) ...[
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 360),
                              child: _buildInputField(
                                label: 'New Password',
                                hint: 'Enter new password',
                                controller: _passwordController,
                                isPassword: true,
                                isSmallScreen: isSmall,
                                prefixIcon: Icons.lock_outline,
                                obscureText: _obscureNew,
                                suffixIcon: IconButton(
                                  tooltip: _obscureNew ? 'Show password' : 'Hide password',
                                  onPressed: () => setState(() => _obscureNew = !_obscureNew),
                                  icon: Icon(_obscureNew ? Icons.visibility_off : Icons.visibility),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 360),
                              child: _buildInputField(
                                label: 'Confirm Password',
                                hint: 'Confirm new password',
                                controller: _confirmPasswordController,
                                isPassword: true,
                                isSmallScreen: isSmall,
                                prefixIcon: Icons.lock_outline,
                                obscureText: _obscureConfirm,
                                suffixIcon: IconButton(
                                  tooltip: _obscureConfirm ? 'Show password' : 'Hide password',
                                  onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm),
                                  icon: Icon(_obscureConfirm ? Icons.visibility_off : Icons.visibility),
                                ),
                              ),
                            ),
                          ],

                          const SizedBox(height: 18),

                          // Кнопка действия
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 360),
                            child: SizedBox(
                              height: 52,
                              child: ElevatedButton(
                                onPressed: _isLoading
                                    ? null
                                    : _currentStep == 0
                                    ? _handleEmailSubmit
                                    : _currentStep == 1
                                    ? _handleCodeVerification
                                    : _handlePasswordReset,
                                child: _isLoading
                                    ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                                    : Text(
                                  _currentStep == 0
                                      ? 'Send Code'
                                      : _currentStep == 1
                                      ? 'Verify Code'
                                      : 'Reset Password',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _codeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
