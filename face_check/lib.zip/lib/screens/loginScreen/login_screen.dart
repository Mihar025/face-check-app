

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../api_client/api/authentication_api.dart';
import '../../api_client/model/authentication_request.dart';
import '../../services/ApiService.dart';
import '../../services/jwt_service.dart';

class LoginScreen extends StatefulWidget {
  final AuthenticationApi authApi;

  const LoginScreen({
    super.key,
    required this.authApi,
  });

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final LocalAuthentication _localAuth = LocalAuthentication();

  bool _isLoading = false;
  bool _isFastLogin = false;
  bool _obscure = true;
  String? _savedUserName;

  @override
  void initState() {
    super.initState();
    _loadSavedCredentials();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _loadSavedCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    final savedEmail = prefs.getString('saved_email');
    final savedName = prefs.getString('user_name');

    if (savedEmail != null) {
      setState(() {
        _emailController.text = savedEmail;
        _savedUserName = savedName;
        _isFastLogin = true;
      });
    }
  }

  Future<void> _saveCredentials(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_email', email);
    final displayName = email.split('@').first;
    await prefs.setString('user_name', displayName);
  }

  Future<void> _authenticateWithBiometrics() async {
    try {
      final canCheckBiometrics = await _localAuth.canCheckBiometrics;
      final isDeviceSupported = await _localAuth.isDeviceSupported();

      if (!canCheckBiometrics || !isDeviceSupported) {
        _showError('Biometric authentication is not available');
        return;
      }

      final didAuthenticate = await _localAuth.authenticate(
        localizedReason: 'Please authenticate to login',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true),
      );

      if (didAuthenticate) {
        await _handleLogin(useSavedPassword: true);
      }
    } catch (_) {
      _showError('Biometric authentication failed');
    }
  }

  Future<void> _handleLogin({bool useSavedPassword = false}) async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await widget.authApi.authenticate(
        authenticationRequest: AuthenticationRequest((b) => b
          ..email = _emailController.text.trim()
          ..password = _passwordController.text.trim()),
      );

      if (response.data?.token == null) {
        throw DioException(
          requestOptions: RequestOptions(path: ''),
          error: 'Token is missing from response',
        );
      }

      await JwtService.decodeAndSaveRole(response.data!.token!);
      await _saveCredentials(_emailController.text);

      final refreshToken = response.data?.refreshToken ?? '';
      await ApiService.instance.setAuthToken(response.data!.token!, refreshToken);

      if (!mounted) return;
      _passwordController.clear();
      _showSuccess('Authentication successful');

      await Future.delayed(const Duration(milliseconds: 300));
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed('/main');
    } on DioException catch (e) {
      String errorMessage = 'Authentication failed';
      if (e.response?.statusCode == 500) {
        errorMessage = 'Server error, please try again';
      } else if (e.response?.statusCode == 401) {
        errorMessage = 'Invalid email or password';
      } else if (e.response?.statusCode == 400) {
        errorMessage = 'Invalid input data';
      } else if (e.type == DioExceptionType.connectionTimeout) {
        errorMessage = 'Connection timeout. Please try again';
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = 'No internet connection';
      }
      _showError(errorMessage);
    } catch (e) {
      _showError('Unexpected error: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.25),
        ),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.25),
        ),
        duration: const Duration(milliseconds: 500),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final insets = MediaQuery.of(context).viewInsets.bottom;
    final isSmall = size.width < 360;

    // Нейтральные цвета под зелёный фон (без градиентов)
    const sheetBg = Color(0xFFFDFDFC); // тёплый «бумажный» белый
    const fieldBg = Color(0xFFFAFAFA); // мягкий фон полей

    // Локальная тема только для этого экрана
    final theme = Theme.of(context).copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: fieldBg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        labelStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w600),
        hintStyle: const TextStyle(color: Colors.black54),
        prefixIconColor: Colors.black87,
        suffixIconColor: Colors.black87,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.black.withOpacity(0.12), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.black, width: 1.4),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.red, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.red, width: 1.2),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: Colors.black87,
          textStyle: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
    );

    return Theme(
      data: theme,
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        extendBodyBehindAppBar: true,
        body: Stack(
          fit: StackFit.expand,
          children: [
            const Image(
              image: AssetImage('assets/images/facecheck2.jpg'),
              fit: BoxFit.cover,
            ),
            // Лёгкий оверлей для читаемости поверх зелёного фона (без градиентов)
            Container(color: Colors.black.withOpacity(0.18)),
            SafeArea(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  16,
                  size.height * 0.35, // опускание формы на 35% экрана
                  16,
                  insets > 0 ? insets + 16 : 24,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: sheetBg,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(24),
                          topRight: Radius.circular(24),
                          bottomLeft: Radius.circular(16),
                          bottomRight: Radius.circular(16),
                        ),
                        border: Border.all(color: Colors.black.withOpacity(0.08)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.14),
                            blurRadius: 26,
                            offset: const Offset(0, 18),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: isSmall ? 14 : 18,
                        vertical: isSmall ? 14 : 18,
                      ),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // «Хэндл» сверху для ощущения системного листа
                            Center(
                              child: Container(
                                width: 44,
                                height: 4.5,
                                margin: const EdgeInsets.only(bottom: 12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.18),
                                  borderRadius: BorderRadius.circular(99),
                                ),
                              ),
                            ),

                            // Fast-login шапка
                            if (_isFastLogin)
                              _FastLoginHeader(
                                name: _savedUserName ?? 'User',
                                onReset: () async {
                                  final prefs = await SharedPreferences.getInstance();
                                  await prefs.remove('saved_email');
                                  await prefs.remove('user_name');
                                  setState(() {
                                    _isFastLogin = false;
                                    _emailController.clear();
                                    _passwordController.clear();
                                    _savedUserName = null;
                                  });
                                },
                              ),
                            if (_isFastLogin) const SizedBox(height: 10),

                            // Заголовок
                            Text(
                              'Sign in',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: isSmall ? 22 : 26,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.2,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Use your email and password',
                              style: TextStyle(color: Colors.black54, fontSize: isSmall ? 13 : 14),
                            ),
                            const SizedBox(height: 16),

                            // Email
                            if (!_isFastLogin)
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                child: TextFormField(
                                  controller: _emailController,
                                  style: const TextStyle(color: Colors.black),
                                  keyboardType: TextInputType.emailAddress,
                                  textInputAction: TextInputAction.next,
                                  autofillHints: const [AutofillHints.email, AutofillHints.username],
                                  validator: (v) {
                                    final value = (v ?? '').trim();
                                    if (value.isEmpty) return 'Email is required';
                                    if (!value.contains('@') || !value.contains('.')) return 'Enter a valid email';
                                    return null;
                                  },
                                  decoration: const InputDecoration(
                                    labelText: 'Email',
                                    hintText: 'email@gmail.com',
                                    prefixIcon: Icon(Icons.alternate_email),
                                  ),
                                ),
                              ),

                            // Password
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: TextFormField(
                                controller: _passwordController,
                                style: const TextStyle(color: Colors.black),
                                obscureText: _obscure,
                                textInputAction: TextInputAction.done,
                                autofillHints: const [AutofillHints.password],
                                onFieldSubmitted: (_) => _handleLogin(),
                                validator: (v) {
                                  final value = (v ?? '').trim();
                                  if (value.isEmpty) return 'Password is required';
                                  if (value.length < 6) return 'At least 6 characters';
                                  return null;
                                },
                                decoration: InputDecoration(
                                  labelText: 'Password',
                                  hintText: 'Your password',
                                  prefixIcon: const Icon(Icons.lock_outline),
                                  suffixIcon: IconButton(
                                    tooltip: _obscure ? 'Show password' : 'Hide password',
                                    onPressed: () => setState(() => _obscure = !_obscure),
                                    icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 4),

                            // Линк + биометрия
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextButton(
                                  onPressed: () => Navigator.of(context).pushNamed('forgot-password'),
                                  child: const Text('Forgot password?'),
                                ),
                                IconButton(
                                  onPressed: _authenticateWithBiometrics,
                                  tooltip: 'Login with biometrics',
                                  icon: const Icon(Icons.fingerprint, size: 28),
                                  style: IconButton.styleFrom(
                                    backgroundColor: Colors.black.withOpacity(0.06),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 12),

                            // Кнопка логина
                            SizedBox(
                              height: 52,
                              child: ElevatedButton(
                                onPressed: _isLoading ? null : () => _handleLogin(),
                                child: _isLoading
                                    ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                                    : const Text('Login'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ————— Доп. виджеты —————

class _FastLoginHeader extends StatelessWidget {
  final String name;
  final VoidCallback onReset;

  const _FastLoginHeader({required this.name, required this.onReset});

  @override
  Widget build(BuildContext context) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : 'U';

    return Row(
      children: [
        CircleAvatar(
          radius: 18,
          backgroundColor: Colors.black,
          child: Text(initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Welcome,', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.black87)),
              Text(name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            ],
          ),
        ),
        TextButton(onPressed: onReset, child: const Text('Not you?')),
      ],
    );
  }
}
