/*
import 'package:face_check/screens/main_menu/drawer/punch_screen/punch_buttons.dart';
import 'package:face_check/screens/main_menu/drawer/punch_screen/work_site_dialog.dart';
import 'package:face_check/screens/main_menu/drawer/punch_screen/work_site_selector.dart';
import 'package:face_check/screens/main_menu/drawer/punch_screen/work_site_service.dart';
import 'package:face_check/screens/main_menu/main_menu_punch_screen/punch_success_dialo.dart';
import 'package:face_check/services/location_tracking_service.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:timezone/timezone.dart' as tz; // ← для сравнения по Нью-Йорку
import 'package:face_check/services/time_service.dart'; // ← защищённое время

import '../../../../../api_client/model/work_site_response.dart';
import '../../../../../api_client/api/worker_attendance_controller_api.dart';
import '../../../../../api_client/serializers.dart';
import '../../../../../services/ApiService.dart';
import '../../../../../providers/localization_provider.dart';
import 'clock_display.dart';
import 'location_service.dart';
import 'map_container.dart';

class PunchScreen extends StatefulWidget {
  const PunchScreen({super.key});

  @override
  State<PunchScreen> createState() => _PunchScreenState();
}

class _PunchScreenState extends State<PunchScreen> with WidgetsBindingObserver {
  late final Dio dio;
  late final LocationService locationService;
  late final WorkSiteService workSiteService;
  late final WorkerAttendanceControllerApi attendanceApi;
  late final TimeService timeService; // ← добавили
  final ImagePicker _imagePicker = ImagePicker();

  late LocationTrackingService _locationTrackingService;
  bool _isTrackingActive = false;

  GoogleMapController? mapController;
  Position? currentPosition;
  WorkSiteResponse? selectedWorkSite;
  bool isLoading = false;
  bool hasPunchIn = false;
  List<WorkSiteResponse> workSites = [];

  // Кэш зоны Нью-Йорка для сравнения "сегодня"
  static final tz.Location _ny = tz.getLocation('America/New_York');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); // ← подписка
    _initializeDependencies();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // ← отписка
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      timeService.sync(); // ← обновим offset при возвращении
    }
  }

  void _initializeDependencies() {
    _initializeDio();
    timeService = TimeService(dio); // ← защищённое время
    locationService = LocationService();
    workSiteService = WorkSiteService(dio);
    attendanceApi = WorkerAttendanceControllerApi(dio, serializers);

    _locationTrackingService = LocationTrackingService(dio);
    Future.wait([
      timeService.sync(), // ← синхронизация серверного времени
      _getCurrentLocation(),
      _loadWorkSites(),
      _checkTodayPunchStatus(),
      _checkTrackingStatus(),
    ]).then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _checkTrackingStatus() async {
    final isActive = await _locationTrackingService.isTrackingActive();
    if (mounted) {
      setState(() {
        _isTrackingActive = isActive;
      });
    }
  }

  void _initializeDio() {
    dio = Dio(BaseOptions(
      baseUrl: 'http://192.168.1.194:8088/api/v1/',
      connectTimeout: const Duration(seconds: 5),
      receiveTimeout: const Duration(seconds: 30),
    ));

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await ApiService.instance.getAuthToken();
        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        return handler.next(options);
      },
      onError: (DioException e, handler) {
        print('Dio Error: ${e.message}');
        return handler.next(e);
      },
    ));
  }

  bool _isSameDayNY(DateTime aUtc, DateTime bUtc) {
    final aNy = tz.TZDateTime.from(aUtc.toUtc(), _ny);
    final bNy = tz.TZDateTime.from(bUtc.toUtc(), _ny);
    return aNy.year == bNy.year && aNy.month == bNy.month && aNy.day == bNy.day;
  }

  Future<void> _checkTodayPunchStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? inStr = prefs.getString('lastPunchInDate');   // ISO-UTC
      final String? outStr = prefs.getString('lastPunchOutDate'); // ISO-UTC

      final DateTime nowUtc = timeService.nowUtc(); // ← защищённое "сейчас" (UTC)

      final DateTime? inUtc =
      (inStr != null && inStr.isNotEmpty) ? DateTime.tryParse(inStr)?.toUtc() : null;
      final DateTime? outUtc =
      (outStr != null && outStr.isNotEmpty) ? DateTime.tryParse(outStr)?.toUtc() : null;

      final bool inToday = (inUtc != null) && _isSameDayNY(inUtc, nowUtc);
      final bool outToday = (outUtc != null) && _isSameDayNY(outUtc, nowUtc);

      if (inToday && outToday) {
        setState(() => hasPunchIn = outUtc!.isAfter(inUtc!) ? false : true);
      } else if (inToday) {
        setState(() => hasPunchIn = true);
      } else {
        setState(() => hasPunchIn = false);
      }

      if ((inStr == null || inStr.isEmpty) && (outStr == null || outStr.isEmpty)) {
        await _checkPunchInStatus();
      }
    } catch (e) {
      print('Error checking punch status: $e');
      await _checkPunchInStatus();
    }
  }

  Future<void> _checkPunchInStatus() async {
    try {
      final lastPunch = await ApiService.instance.getLastPunchTime();
      if (mounted) {
        setState(() {
          hasPunchIn = lastPunch.time != '--:--';
        });
      }
    } catch (e) {
      print('Error checking punch in status: $e');
    }
  }

  Future<void> _loadWorkSites() async {
    if (!mounted) return;
    setState(() => isLoading = true);

    try {
      final sites = await workSiteService.loadWorkSites();
      if (!mounted) return;

      setState(() {
        workSites = sites;
        if (sites.isNotEmpty && selectedWorkSite == null) {
          selectedWorkSite = sites.first;
        }
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() => isLoading = false);
      _showErrorSnackBar('Failed to load work sites: $e');
    }
  }

  void _showErrorSnackBar(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _getCurrentLocation() async {
    final position = await locationService.getCurrentLocation();
    if (mounted && position != null) {
      setState(() => currentPosition = position);
    }
  }

  Future<void> _showWorkSiteDialog() async {
    final theme = Theme.of(context);

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Theme(
        data: theme,
        child: WorkSiteDialog(
          workSites: workSites,
          isLoading: isLoading,
          onRefresh: _loadWorkSites,
          onSelect: (site) async {
            try {
              await workSiteService.selectWorkSite(site.workSiteId ?? 0);

              if (!mounted) return;

              setState(() {
                selectedWorkSite = site;
              });

              Navigator.of(dialogContext).pop();
            } catch (e) {
              if (!mounted) return;

              Navigator.of(dialogContext).pop();
              _showErrorSnackBar('Failed to select work site: $e');
            }
          },
        ),
      ),
    );
  }

  Future<String?> _captureImage() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
      );

      if (image != null) {
        final File imageFile = File(image.path);
        final bytes = await imageFile.readAsBytes();
        return base64Encode(bytes);
      }
      return null;
    } catch (e) {
      print('Error capturing image: $e');
      return null;
    }
  }

  // Форматируем защищённое NY-время для диалогов
  String _getCurrentFormattedTime() {
    final nyNow = tz.TZDateTime.from(timeService.nowUtc(), _ny);
    return DateFormat('HH:mm:ss').format(nyNow);
  }

  void _showSuccessDialog(bool isPunchIn, String time) {
    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => PunchSuccessDialog(
        isPunchIn: isPunchIn,
        time: time,
        onOk: () => Navigator.of(dialogContext).pop(),
      ),
    );
  }

  Future<void> _handlePunchIn() async {
    if (selectedWorkSite == null || currentPosition == null) {
      _showErrorSnackBar('Please select work site and enable location');
      return;
    }

    final String? photoBase64 = await _captureImage();
    if (photoBase64 == null) {
      return;
    }

    try {
      setState(() => isLoading = true);

      final Map<String, dynamic> requestData = {
        'workSiteId': selectedWorkSite?.workSiteId,
        'photoBase64': photoBase64,
        'latitude': currentPosition?.latitude,
        'longitude': currentPosition?.longitude
      };

      final response = await dio.post(
        'attendance/punch-in',
        data: requestData,
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        // ДОБАВИТЬ: Запуск трекинга локации
        final prefs = await SharedPreferences.getInstance();
        final userId = prefs.getInt('user_id') ?? 0; // Получите правильный user ID

        // Запускаем трекинг
        await _locationTrackingService.startTracking(userId);

        final nowUtcIso = timeService.nowUtc().toIso8601String();
        await prefs.setString('lastPunchInDate', nowUtcIso);

        setState(() {
          isLoading = false;
          hasPunchIn = true;
          _isTrackingActive = true; // ДОБАВИТЬ
        });

        final currentTime = _getCurrentFormattedTime();
        _showSuccessDialog(true, currentTime);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('Punched in! Location tracking started'),
              ],
            ),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        _showErrorSnackBar('Failed to punch in');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);
      _showErrorSnackBar('Failed to punch in: $e');
    }
  }


  Future<void> _handlePunchOut() async {
    if (selectedWorkSite == null || currentPosition == null) {
      _showErrorSnackBar('Please select work site and enable location');
      return;
    }

    final String? photoBase64 = await _captureImage();
    if (photoBase64 == null) {
      return;
    }

    try {
      setState(() => isLoading = true);

      final Map<String, dynamic> requestData = {
        'workSiteId': selectedWorkSite?.workSiteId,
        'photoBase64': photoBase64,
        'latitude': currentPosition?.latitude,
        'longitude': currentPosition?.longitude
      };

      final response = await dio.post(
        'attendance/punch-out',
        data: requestData,
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        // ДОБАВИТЬ: Остановка трекинга локации
        await _locationTrackingService.stopTracking();

        final prefs = await SharedPreferences.getInstance();
        final nowUtcIso = timeService.nowUtc().toIso8601String();
        await prefs.setString('lastPunchOutDate', nowUtcIso);

        setState(() {
          isLoading = false;
          hasPunchIn = false;
          _isTrackingActive = false; // ДОБАВИТЬ
        });

        final currentTime = _getCurrentFormattedTime();
        _showSuccessDialog(false, currentTime);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.stop_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('Punched out! Location tracking stopped'),
              ],
            ),
            backgroundColor: Colors.blue,
          ),
        );
      } else {
        _showErrorSnackBar('Failed to punch out');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);
      _showErrorSnackBar('Failed to punch out: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = context.read<LocalizationProvider>().localizations;

    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 360;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.scaffoldBackgroundColor,
        elevation: 0,
        title: Text(
          l10n.get('punch'),
          style: TextStyle(
            color: theme.textTheme.titleLarge?.color,
            fontSize: isSmallScreen ? 20 : 22,
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: EdgeInsets.all(isSmallScreen ? 6 : 8),
            decoration: BoxDecoration(
              color: theme.brightness == Brightness.dark
                  ? Colors.white.withOpacity(0.05)
                  : Colors.black.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              color: theme.iconTheme.color,
              size: isSmallScreen ? 18 : 20,
            ),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),

      body: Stack(
          children: [
          SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ДОБАВИТЬ: Индикатор активного трекинга
          if (_isTrackingActive)
            Container(
              margin: EdgeInsets.symmetric(
                horizontal: isSmallScreen ? 16 : 20,
                vertical: 8,
              ),
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.green.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Colors.green,
                        size: 20,
                      ),
                      // Пульсирующая анимация
                      TweenAnimationBuilder<double>(
                        tween: Tween(begin: 1.0, end: 1.5),
                        duration: Duration(seconds: 1),
                        builder: (context, value, child) {
                          return Container(
                            width: 30 * value,
                            height: 30 * value,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.green.withOpacity(0.5 / value),
                                width: 2,
                              ),
                            ),
                          );
                        },
                        onEnd: () {
                          // Зацикливаем анимацию
                          if (mounted && _isTrackingActive) {
                            setState(() {});
                          }
                        },
                      ),
                    ],
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Location Tracking Active',
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          'Your location is being tracked every 5 minutes',
                          style: TextStyle(
                            color: Colors.green.withOpacity(0.8),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    ),

        ],
                  ),
                ),

                // Work Site Selector
                Container(
                  margin: EdgeInsets.symmetric(
                    horizontal: isSmallScreen ? 16 : 20,
                    vertical: isSmallScreen ? 8 : 12,
                  ),
                  child: WorkSiteSelectorButton(
                    selectedWorkSite: selectedWorkSite,
                    onTap: _showWorkSiteDialog,
                    backgroundColor: theme.brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.05)
                        : Colors.white,
                    textColor: theme.textTheme.bodyLarge?.color,
                    isSmallScreen: isSmallScreen,
                  ),
                ),

                // Status Indicator
                if (hasPunchIn)
                  Container(
                    margin: EdgeInsets.symmetric(
                      horizontal: isSmallScreen ? 16 : 20,
                      vertical: isSmallScreen ? 8 : 12,
                    ),
                    padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: Colors.green.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.check_circle_rounded,
                          color: Colors.green,
                          size: isSmallScreen ? 20 : 24,
                        ),
                        SizedBox(width: isSmallScreen ? 8 : 12),
                        Text(
                          'You are currently punched in',
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: isSmallScreen ? 14 : 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),

                SizedBox(height: isSmallScreen ? 80 : 100),
              ],
            ),
          ),

          // Loading Overlay
          if (isLoading)
            Container(
              color: Colors.black54,
              child: Center(
                child: Container(
                  padding: EdgeInsets.all(isSmallScreen ? 20 : 24),
                  decoration: BoxDecoration(
                    color: theme.scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(
                        color: Colors.blue,
                        strokeWidth: 3,
                      ),
                      SizedBox(height: isSmallScreen ? 12 : 16),
                      Text(
                        'Processing...',
                        style: TextStyle(
                          color: theme.textTheme.bodyMedium?.color,
                          fontSize: isSmallScreen ? 14 : 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: theme.scaffoldBackgroundColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: PunchButtons(
          onPunchIn: isLoading ? null : _handlePunchIn,
          onPunchOut: isLoading ? null : _handlePunchOut,
          backgroundColor: theme.scaffoldBackgroundColor,
          buttonColor: theme.brightness == Brightness.dark
              ? Colors.white.withOpacity(0.05)
              : Colors.white,
          textColor: theme.textTheme.bodyLarge?.color,
        ),
      ),
    );
  }
}


 */