/*
import 'package:face_check/screens/main_menu/main_menu_punch_screen/punch_success_dialo.dart';
import 'package:face_check/services/time_service.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:timezone/timezone.dart' as tz;

import '../../../providers/localization_provider.dart';
import '../../../services/ApiService.dart';
import '../../../../../api_client/model/work_site_response.dart';
import '../../../../../api_client/api/worker_attendance_controller_api.dart';
import '../../../../../api_client/serializers.dart';
import '../../../services/location_tracking_service.dart';
import '../../../utils/error_handler.dart';
import '../../../widgets/error_dialog.dart';
import '../drawer/punch_screen/clock_display.dart';
import '../drawer/punch_screen/location_service.dart';
import '../drawer/punch_screen/map_container.dart';
import '../drawer/punch_screen/work_site_dialog.dart';
import '../drawer/punch_screen/work_site_selector.dart';
import '../drawer/punch_screen/work_site_service.dart';

class Mainmenupunchscreen extends StatefulWidget {
  const Mainmenupunchscreen({super.key});

  @override
  State<Mainmenupunchscreen> createState() => _FaceCheckScreenState();
}

class _FaceCheckScreenState extends State<Mainmenupunchscreen>
    with WidgetsBindingObserver {
  late final Dio dio;
  late final LocationService locationService;
  late final WorkSiteService workSiteService;
  late final WorkerAttendanceControllerApi attendanceApi;
  late final TimeService timeService;
  final ImagePicker _imagePicker = ImagePicker();

  late LocationTrackingService _locationTrackingService;
  bool _isTrackingActive = false;
  int? _currentUserId; // Добавляем переменную для хранения userId

  GoogleMapController? mapController;
  Position? currentPosition;
  WorkSiteResponse? selectedWorkSite;
  bool isLoading = false;
  bool hasPunchIn = false;
  List<WorkSiteResponse> workSites = [];

  static final tz.Location _ny = tz.getLocation('America/New_York');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeDependencies();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      timeService.sync().then((_) => _checkTodayPunchStatus());
    }
  }

  void _initializeDependencies() async {
    _initializeDio();
    timeService = TimeService(dio);
    locationService = LocationService();
    workSiteService = WorkSiteService(dio);
    attendanceApi = WorkerAttendanceControllerApi(dio, serializers);

    _locationTrackingService = LocationTrackingService(dio);

    // Получаем userId при инициализации
    await _fetchAndSaveUserId();

    // ВАЖНО: последовательно, чтобы nowUtc уже был со смещением
    await timeService.sync();
    await _getCurrentLocation();
    await _loadWorkSites();
    await _checkTodayPunchStatus();
    await _checkTrackingStatus();

    if (mounted) setState(() {});
  }

  // Новый метод для получения и сохранения userId
  Future<void> _fetchAndSaveUserId() async {
    try {
      print('📱 Fetching user ID from server...');

      final response = await dio.get('user/current'); // Adjust endpoint path as needed

      if (response.statusCode == 200 && response.data != null) {
        // Парсим ответ в UserIdResponse
        final userIdResponse = UserIdResponse.fromJson(response.data);

        if (userIdResponse.userId != null) {
          // Сохраняем в SharedPreferences
          final prefs = await SharedPreferences.getInstance();
          await prefs.setInt('user_id', userIdResponse.userId!);

          // Сохраняем в состояние для отображения
          setState(() {
            _currentUserId = userIdResponse.userId;
          });

          print('✅ User ID successfully fetched and saved: ${userIdResponse.userId}');
          print('📍 User ID will be used for location tracking');
        } else {
          print('⚠️ User ID is null in response');
        }
      }
    } catch (e) {
      print('❌ Error fetching user ID: $e');

      // Пробуем получить из SharedPreferences если есть сохранённый
      final prefs = await SharedPreferences.getInstance();
      final savedUserId = prefs.getInt('user_id');

      if (savedUserId != null && savedUserId != 0) {
        setState(() {
          _currentUserId = savedUserId;
        });
        print('📦 Using cached user ID: $savedUserId');
      } else {
        print('⚠️ No cached user ID found');
      }
    }
  }

  Future<void> _checkTrackingStatus() async {
    final isActive = await _locationTrackingService.isTrackingActive();
    if (mounted) {
      setState(() {
        _isTrackingActive = isActive;
      });

      if (isActive && _currentUserId != null) {
        print('🌍 Location tracking is active for user ID: $_currentUserId');
      }
    }
  }

  void _initializeDio() {
    dio = Dio(BaseOptions(
      baseUrl: 'http://192.168.1.194:8088/api/v1/',
      connectTimeout: const Duration(seconds: 5),
      receiveTimeout: const Duration(seconds: 30),
    ));

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await ApiService.instance.getAuthToken();
        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        return handler.next(options);
      },
      onError: (DioException e, handler) {
        print('Dio Error: ${e.message}');
        return handler.next(e);
      },
    ));
  }

  // Сравнение «один и тот же день» именно по часовому поясу NY
  bool _isSameDayNY(DateTime aUtc, DateTime bUtc) {
    final aNy = tz.TZDateTime.from(aUtc.toUtc(), _ny);
    final bNy = tz.TZDateTime.from(bUtc.toUtc(), _ny);
    return aNy.year == bNy.year && aNy.month == bNy.month && aNy.day == bNy.day;
  }

  // Утилита: NY-строка YYYY-MM-DD для отладки/ключей (если понадобится)
  String _nyYmd(DateTime utc) {
    final d = tz.TZDateTime.from(utc.toUtc(), _ny);
    return '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
  }

  Future<void> _checkTodayPunchStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Быстрый флаг, если есть (ускоряет UX при возврате)
      final bool? flag = prefs.getBool('isPunchedInToday');
      if (flag != null) {
        setState(() => hasPunchIn = flag);
      }

      final String? inStr  = prefs.getString('lastPunchInDate');   // ISO-UTC
      final String? outStr = prefs.getString('lastPunchOutDate');  // ISO-UTC

      final DateTime nowUtc = timeService.nowUtc(); // «сейчас» — защищённое UTC

      final DateTime? inUtc  = (inStr  != null && inStr.isNotEmpty)  ? DateTime.tryParse(inStr )?.toUtc() : null;
      final DateTime? outUtc = (outStr != null && outStr.isNotEmpty) ? DateTime.tryParse(outStr)?.toUtc() : null;

      // Почистим устаревший OUT: если он не за сегодня — не учитываем его в логике
      DateTime? effectiveOutUtc = outUtc;
      if (effectiveOutUtc != null && !_isSameDayNY(effectiveOutUtc, nowUtc)) {
        effectiveOutUtc = null;
      }

      bool? derived; // null => локально определить не удалось

      // Кейс 1: есть IN и нет актуального OUT, и IN сегодня по NY => внутри
      if (inUtc != null && effectiveOutUtc == null && _isSameDayNY(inUtc, nowUtc)) {
        derived = true;
      }
      // Кейс 2: есть и IN, и OUT (оба за сегодня или хотя бы один за сегодня)
      else if (inUtc != null && effectiveOutUtc != null) {
        final bool inToday  = _isSameDayNY(inUtc, nowUtc);
        final bool outToday = _isSameDayNY(effectiveOutUtc, nowUtc);

        if (inToday || outToday) {
          // если OUT позже IN — сейчас "снаружи", иначе "внутри"
          derived = effectiveOutUtc.isAfter(inUtc) ? false : true;
        }
      }
      // Кейс 3: есть только OUT за сегодня — снаружи
      else if (inUtc == null && effectiveOutUtc != null) {
        derived = false;
      }

      if (derived != null) {
        if (!mounted) return;
        setState(() => hasPunchIn = derived!);

        // синхронизируем быстрый флаг (для моментального UX при следующем входе)
        await prefs.setBool('isPunchedInToday', hasPunchIn);
        return;
      }

      // Фоллбек: ничего не меняем (или можно жёстко сбрасывать в false — на твой вкус)
      if (mounted) setState(() {/* keep current */});
    } catch (e) {
      print('Error checking punch status: $e');
      if (mounted) setState(() {/* keep current */});
    }
  }

  Future<void> _loadWorkSites() async {
    if (!mounted) return;
    setState(() => isLoading = true);

    try {
      final sites = await workSiteService.loadWorkSites();
      if (!mounted) return;

      setState(() {
        workSites = sites;
        if (sites.isNotEmpty && selectedWorkSite == null) {
          selectedWorkSite = sites.first;
        }
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() => isLoading = false);
      _showErrorSnackBar('Failed to load work sites: $e');
    }
  }

  void _showErrorSnackBar(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _getCurrentLocation() async {
    final position = await locationService.getCurrentLocation();
    if (mounted && position != null) {
      setState(() => currentPosition = position);
    }
  }

  Future<void> _showWorkSiteDialog() async {
    final theme = Theme.of(context);

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Theme(
        data: theme,
        child: WorkSiteDialog(
          workSites: workSites,
          isLoading: isLoading,
          onRefresh: _loadWorkSites,
          onSelect: (site) async {
            try {
              await workSiteService.selectWorkSite(site.workSiteId ?? 0);

              if (!mounted) return;

              setState(() {
                selectedWorkSite = site;
              });

              Navigator.of(dialogContext).pop();
            } catch (e) {
              if (!mounted) return;

              Navigator.of(dialogContext).pop();
              _showErrorSnackBar('Failed to select work site: $e');
            }
          },
        ),
      ),
    );
  }

  Future<String?> _captureImage() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
      );

      if (image != null) {
        final File imageFile = File(image.path);
        final bytes = await imageFile.readAsBytes();
        return base64Encode(bytes);
      }
      return null;
    } catch (e) {
      print('Error capturing image: $e');
      return null;
    }
  }

  // Форматируем «защищённое» NY-время для диалога
  String _getCurrentFormattedTime() {
    final nyNow = timeService.nowNY();
    return DateFormat('HH:mm:ss').format(nyNow);
  }

  void _showSuccessDialog(bool isPunchIn, String time) {
    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => PunchSuccessDialog(
        isPunchIn: isPunchIn,
        time: time,
        onOk: () => Navigator.of(dialogContext).pop(),
      ),
    );
  }

  Future<void> _handlePunchInOut() async {
    if (!hasPunchIn) {
      await _handlePunchInWithCamera();
    } else {
      await _handlePunchOutWithCamera();
    }
  }

  Future<void> _handlePunchInWithCamera() async {
    // Валидация перед отправкой
    if (selectedWorkSite == null) {
      _showErrorDialog(
        title: 'Work Site Required',
        message: 'Please select a work site before punching in.',
      );
      return;
    }

    if (currentPosition == null) {
      _showErrorDialog(
        title: 'Location Required',
        message: 'Please enable location services to punch in.',
        onRetry: _getCurrentLocation,
      );
      return;
    }

    final String? photoBase64 = await _captureImage();
    if (photoBase64 == null) {
      _showErrorDialog(
        title: 'Photo Required',
        message: 'A photo is required to punch in. Please take a photo.',
      );
      return;
    }

    try {
      setState(() => isLoading = true);

      final Map<String, dynamic> requestData = {
        'workSiteId': selectedWorkSite?.workSiteId,
        'photoBase64': photoBase64,
        'latitude': currentPosition?.latitude,
        'longitude': currentPosition?.longitude
      };

      final response = await dio.post(
        'attendance/punch-in',
        data: requestData,
      );

      if (!mounted) return;

      if (response.statusCode! >= 200 && response.statusCode! < 300) {
        final prefs = await SharedPreferences.getInstance();
        final nowUtcIso = timeService.nowUtc().toIso8601String();

        // Используем правильный userId вместо 0
        final userId = prefs.getInt('user_id') ?? _currentUserId ?? 0;

        print('🚀 Starting location tracking for user ID: $userId');
        await _locationTrackingService.startTracking(userId);

        await prefs.setString('lastPunchInDate', nowUtcIso);
        await prefs.setBool('isPunchedInToday', true);

        // Очистка старого punch out если нужно
        final String? outStr = prefs.getString('lastPunchOutDate');
        if (outStr != null && outStr.isNotEmpty) {
          final DateTime? outUtc = DateTime.tryParse(outStr)?.toUtc();
          if (outUtc != null) {
            final inUtc = DateTime.tryParse(nowUtcIso)!.toUtc();
            if (!_isSameDayNY(outUtc, inUtc) || !outUtc.isAfter(inUtc)) {
              await prefs.remove('lastPunchOutDate');
            }
          }
        }

        setState(() {
          isLoading = false;
          hasPunchIn = true;
          _isTrackingActive = true;
        });

        final currentTime = _getCurrentFormattedTime();
        _showSuccessDialog(true, currentTime);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Location tracking started for user: $userId'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);

      // Используем наш ErrorHandler
      final errorMessage = ErrorHandler.getErrorMessage(e);

      // Показываем красивый диалог с ошибкой
      _showErrorDialog(
        title: 'Punch In Failed',
        message: errorMessage,
        details: _isDebugMode() ? e.toString() : null, // Детали только в debug
        onRetry: () => _handlePunchInWithCamera(),
      );
    }
  }

  Future<void> _handlePunchOutWithCamera() async {
    // Валидация
    if (selectedWorkSite == null) {
      _showErrorDialog(
        title: 'Work Site Required',
        message: 'Please select a work site before punching out.',
      );
      return;
    }

    if (currentPosition == null) {
      _showErrorDialog(
        title: 'Location Required',
        message: 'Please enable location services to punch out.',
        onRetry: _getCurrentLocation,
      );
      return;
    }

    final String? photoBase64 = await _captureImage();
    if (photoBase64 == null) {
      _showErrorDialog(
        title: 'Photo Required',
        message: 'A photo is required to punch out. Please take a photo.',
      );
      return;
    }

    try {
      setState(() => isLoading = true);

      final Map<String, dynamic> requestData = {
        'workSiteId': selectedWorkSite?.workSiteId,
        'photoBase64': photoBase64,
        'latitude': currentPosition?.latitude,
        'longitude': currentPosition?.longitude
      };

      final response = await dio.post(
        'attendance/punch-out',
        data: requestData,
      );

      if (!mounted) return;

      if (response.statusCode! >= 200 && response.statusCode! < 300) {

        print('🛑 Stopping location tracking for user ID: $_currentUserId');
        await _locationTrackingService.stopTracking();

        final prefs = await SharedPreferences.getInstance();
        final nowUtcIso = timeService.nowUtc().toIso8601String();

        await prefs.setString('lastPunchOutDate', nowUtcIso);
        await prefs.setBool('isPunchedInToday', false);

        setState(() {
          isLoading = false;
          hasPunchIn = false;
          _isTrackingActive = false;
        });

        final currentTime = _getCurrentFormattedTime();
        _showSuccessDialog(false, currentTime);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Location tracking stopped for user: $_currentUserId'),
            backgroundColor: Colors.blue,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);

      final errorMessage = ErrorHandler.getErrorMessage(e);

      _showErrorDialog(
        title: 'Punch Out Failed',
        message: errorMessage,
        details: _isDebugMode() ? e.toString() : null,
        onRetry: () => _handlePunchOutWithCamera(),
      );
    }
  }

  // 4. Вспомогательные методы для показа диалогов
  void _showErrorDialog({
    required String title,
    required String message,
    String? details,
    VoidCallback? onRetry,
  }) {
    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => ErrorDialog(
        title: title,
        message: message,
        details: details,
        onRetry: onRetry,
      ),
    );
  }

  // Проверка debug режима
  bool _isDebugMode() {
    bool inDebugMode = false;
    assert(inDebugMode = true);
    return inDebugMode;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final l10n = context.read<LocalizationProvider>().localizations;

    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 360;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.scaffoldBackgroundColor,
        elevation: 0,
        title: Text(
          l10n.get('punch'),
          style: TextStyle(
            color: theme.textTheme.titleLarge?.color,
            fontSize: isSmallScreen ? 18 : 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: theme.iconTheme.color,
            size: isSmallScreen ? 22 : 24,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        // Добавляем отображение userId в AppBar для дебага (можно убрать в продакшене)
        actions: _isDebugMode() && _currentUserId != null
            ? [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'ID: $_currentUserId',
                style: TextStyle(
                  color: theme.textTheme.bodySmall?.color,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ]
            : null,
      ),
      body: Stack(
        children: [
          Container(
            color: theme.scaffoldBackgroundColor,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: isSmallScreen ? 16 : 20),
                ClockDisplay(
                  textColor: theme.textTheme.bodyLarge?.color ?? Colors.white,
                  isSmallScreen: isSmallScreen,
                  timeStream: timeService.nyTicker(), // поток NY-времени
                ),
                SizedBox(height: isSmallScreen ? 16 : 20),
                MapContainer(
                  currentPosition: currentPosition,
                  onMapCreated: (controller) => mapController = controller,
                ),
                SizedBox(height: isSmallScreen ? 16 : 20),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: isSmallScreen ? 12 : 16),
                  child: WorkSiteSelectorButton(
                    selectedWorkSite: selectedWorkSite,
                    onTap: _showWorkSiteDialog,
                    backgroundColor: theme.brightness == Brightness.dark
                        ? Colors.grey[900]
                        : Colors.grey[100],
                    textColor: theme.textTheme.bodyLarge?.color,
                    isSmallScreen: isSmallScreen,
                  ),
                ),
                SizedBox(height: isSmallScreen ? 16 : 20),
                // Отображение статуса трекинга для дебага
                if (_isDebugMode() && _isTrackingActive && _currentUserId != null)
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.green.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.green, size: 16),
                          SizedBox(width: 8),
                          Text(
                            'Tracking active for user: $_currentUserId',
                            style: TextStyle(
                              color: Colors.green,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (isLoading)
            Container(
              color: Colors.black54,
              child: Center(
                child: CircularProgressIndicator(
                  color: theme.brightness == Brightness.dark ? Colors.white : Colors.blue,
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: Container(
        color: theme.scaffoldBackgroundColor,
        padding: EdgeInsets.only(bottom: isSmallScreen ? 16 : 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: isLoading ? null : _handlePunchInOut,
                borderRadius: BorderRadius.circular(isSmallScreen ? 22 : 25),
                child: Container(
                  width: isSmallScreen ? 65 : 75,
                  height: isSmallScreen ? 65 : 75,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (hasPunchIn ? Colors.blue : Colors.green).withOpacity(0.2),
                    border: Border.all(
                      color: hasPunchIn ? Colors.blue : Colors.green,
                      width: isSmallScreen ? 1.5 : 2,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        hasPunchIn ? Icons.logout : Icons.login,
                        color: hasPunchIn ? Colors.blue : Colors.green,
                        size: isSmallScreen ? 20 : 24,
                      ),
                      SizedBox(height: isSmallScreen ? 2 : 4),
                      Text(
                        hasPunchIn ? l10n.get('punchOut') : l10n.get('punchIn'),
                        style: TextStyle(
                          color: hasPunchIn ? Colors.blue : Colors.green,
                          fontSize: isSmallScreen ? 10 : 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

 */