class AppLocalizations {
  final String languageCode;

  AppLocalizations(this.languageCode);

  static final Map<String, Map<String, String>> _localizedValues = {
    'en': {
      // Notifications
      'notifications.title': 'Notifications',
      'notifications.clearAll': 'Clear All',
      'notifications.noNotifications': 'No incoming notifications',
      'refresh': 'Refresh',

      // Daily Notifications
      'dailyPunchIn.title': 'Dont forget to make Punch In!',
      'dailyPunchIn.body': 'Open an application, and make Punch In!',
      'dailyPunchOut.title': 'Dont forget to make Punch Out!',
      'dailyPunchOut.body': 'Open an application, and make Punch Out!',
      'weeklyHoursCheck.title': 'Check and be consider that your worked hours are correct!',
      'weeklyHoursCheck.body': 'Check and be consider that your worked hours are correct! If you have an issue please contact with your Manager, and provide him information!',

      // Main Menu
      'viewDetails': 'View Details',
      'lastPunch': 'Last Punch',

      // Settings - General
      'settings': 'Settings',
      'profile': 'Profile',
      'phoneNumber': 'Phone Number',
      'email': 'Email',
      'password': 'Password',
      'preferences': 'Preferences',
      'timeFormat': 'Time Format',
      'theme': 'Theme',
      'dark': 'Dark',
      'white': 'White',
      'language': 'Language',
      'english': 'English',
      'spanish': 'Spanish',
      'russian': 'Russian',
      'cancel': 'Cancel',
      'save': 'Save',

      // Settings - Phone
      'editPhoneNumber': 'Edit Phone Number',
      'currentPhoneNumber': 'Current Phone Number',
      'currentPhoneNumberHint': 'Enter current phone number',
      'newPhoneNumber': 'New Phone Number',
      'newPhoneNumberHint': 'Enter new phone number',
      'confirmNewPhoneNumber': 'Confirm New Phone Number',
      'confirmNewPhoneNumberHint': 'Confirm new phone number',
      'phoneNumbersDoNotMatch': 'Phone numbers do not match',
      'phoneNumberUpdated': 'Phone number updated successfully',

      // Settings - Email
      'editEmail': 'Edit Email',
      'currentEmail': 'Current Email',
      'currentEmailHint': 'Enter current email',
      'new': 'New',
      'сonfirmNew': 'Confirm New',
      'emailsDoNotMatch': 'Emails do not match',
      'emailUpdated': 'Email updated successfully',

      // Settings - Password
      'changePassword': 'Change Password',
      'currentPassword': 'Current Password',
      'newPassword': 'New Password',
      'confirmNewPassword': 'Confirm New Password',
      //Profile
      'updateImage': 'Update Image',
      'fullName': 'Full Name',
      'address': 'Address',
      'contactInformation' :'Contact Information',
      //Punch Screen
      'selectWorkSite': 'Select Work Site',
      'searchWorkSites': 'Search WorkSite',
      'unnamedSite': 'Unnamed Site',
      'noAddress': 'No Address',
      'punchIn': 'Punch In',
      'punchOut': 'Punch Out',
      'punch': 'Punch',
      'home': 'Home',
      'logout': 'Logout',
      'finance': 'Finance',
      'workedHours': 'Worked Hours:',

      // View Details Screen
      'productivity': 'Productivity',
      'attendance': 'Attendance',
      'hours': 'Hours',
      'overtime': 'Overtime',
      'missedHours': 'Missed Hours',
      'period': 'Period',
      'workerPayroll': 'Worker Payroll',
      'hourlyRate': 'Hourly Rate',
      'gross': 'Gross',
      'totalTaxes': 'Total Taxes',
      'netTotal': 'Net Total',
      'workerFinancialStatistics': 'Worker Financial Statistics',
      'earningsDynamics': 'Earnings Dynamics',
      'noDataAvailable': 'No data available',
      'employee': 'Employee',

      //Finance Page
      "finance.title": "Finance",
      "finance.downloadPdfReport": "Generating PDF report...",
      "finance.reportDownloadedSuccessfully": "Report downloaded successfully",
      "finance.errorDownloadingReport": "Error downloading report",
      "finance.errorLoadingData": "Error loading data",
      "finance.downloadTooltip": "Download PDF Report",
      "finance.shareTooltip": "Share Summary",
      "finance.shareTitle": "Finance Summary",
      "finance.totalHours": "Total Hours",
      "finance.totalGrossPay": "Total Gross Pay",
      "finance.totalNetPay": "Total Net Pay",
      "finance.totalTaxes": "Total Taxes",
      "finance.previous": "Previous",
      "finance.next": "Next",
      "finance.weekPeriod": "Week Period",
      "finance.hours": "Hours",
      "finance.gross": "Gross",
      "finance.net": "Net",
      "finance.day": "Day",
      "finance.noDataForPeriod": "No data for this period",
      "finance.refresh": "Refresh",
      "finance.totals": "Totals",

      "employee.title": "Employees",
      "employee.subtitle": "Select Work Site for Details",
      "employee.searchHint": "Search work sites...",
      "employee.error": "Failed to load work sites",
      "employee.retry": "Retry",

      // Worksite Employees Screen
      "worksiteEmployees.title": "Employees",
      "worksiteEmployees.subtitle": "Work Site #",
      "worksiteEmployees.refresh": "Refresh",
      "worksiteEmployees.loading": "Loading employees...",
      "worksiteEmployees.emptyTitle": "No one has checked in yet",
      "worksiteEmployees.emptyDescription": "Employees who have checked in at this site will appear here.",
      "worksiteEmployees.errorTitle": "Something went wrong",
      "worksiteEmployees.errorDescription": "Failed to load data. Check your connection and try again.",
      "worksiteEmployees.tryAgain": "Try again",
      "worksiteEmployees.deleteCheckIn": "Delete check-in",
      "worksiteEmployees.updateTime": "Update time",
      "worksiteEmployees.checkInTime": "Check-in time:",
      "worksiteEmployees.confirmTitle": "Confirmation",
      "worksiteEmployees.confirmDeleteTime": "Are you sure you want to delete the check-in time?",
      "worksiteEmployees.cancel": "Cancel",
      "worksiteEmployees.delete": "Delete",
      "worksiteEmployees.timeUpdated": "Time updated:",
      "worksiteEmployees.timeUpdatedSuccess": "Time successfully updated",
      "worksiteEmployees.timeDeleted": "Check-in time successfully deleted",
      "worksiteEmployees.error": "Error:",
      "worksiteEmployees.enterTime": "Enter time",
      "worksiteEmployees.todayDate": "Today's date will be used automatically",
      "worksiteEmployees.ready": "Done",
      "worksiteEmployees.enterValidTime": "Please enter a valid time",
      'weeklyProgress' : 'Weekly Progress'

    },

    'es': {
      // Notifications
      'notifications.title': 'Notificaciones',
      'notifications.clearAll': 'Limpiar todo',
      'notifications.noNotifications': 'No hay notificaciones entrantes',

      // Daily Notifications
      'dailyPunchIn.title': '¡No olvide registrar su entrada!',
      'dailyPunchIn.body': '¡Abra la aplicación y registre su entrada!',
      'dailyPunchOut.title': '¡No olvide registrar su salida!',
      'dailyPunchOut.body': '¡Abra la aplicación y registre su salida!',
      'weeklyHoursCheck.title': '¡Verifique que sus horas trabajadas sean correctas!',
      'weeklyHoursCheck.body': '¡Verifique que sus horas trabajadas sean correctas! Si tiene algún problema, comuníquese con su Gerente y proporciónele la información!',

      // Main Menu
      'viewDetails': 'Ver Detalles',
      'lastPunch': 'Último Registro',

      // Settings - General
      'settings': 'Configuración',
      'profile': 'Perfil',
      'phoneNumber': 'Número de Teléfono',
      'email': 'Correo Electrónico',
      'password': 'Contraseña',
      'preferences': 'Preferencias',
      'timeFormat': 'Formato de Hora',
      'theme': 'Tema',
      'dark': 'Oscuro',
      'white': 'Claro',
      'language': 'Idioma',
      'english': 'Inglés',
      'spanish': 'Español',
      'russian': 'Ruso',
      'cancel': 'Cancelar',
      'save': 'Guardar',

      // Settings - Phone
      'editPhoneNumber': 'Editar Número de Teléfono',
      'currentPhoneNumber': 'Número de Teléfono Actual',
      'currentPhoneNumberHint': 'Ingrese el número de teléfono actual',
      'newPhoneNumber': 'Nuevo Número de Teléfono',
      'newPhoneNumberHint': 'Ingrese el nuevo número de teléfono',
      'confirmNewPhoneNumber': 'Confirmar Nuevo Número de Teléfono',
      'confirmNewPhoneNumberHint': 'Confirme el nuevo número de teléfono',
      'phoneNumbersDoNotMatch': 'Los números de teléfono no coinciden',
      'phoneNumberUpdated': 'Número de teléfono actualizado con éxito',

      // Settings - Email
      'editEmail': 'Editar Correo Electrónico',
      'currentEmail': 'Correo Electrónico Actual',
      'currentEmailHint': 'Ingrese el correo electrónico actual',
      'new': 'Nuevo',
      'сonfirmNew': 'Confirmar Nuevo',
      'emailsDoNotMatch': 'Los correos electrónicos no coinciden',
      'emailUpdated': 'Correo electrónico actualizado con éxito',

      // Settings - Password
      'changePassword': 'Cambiar Contraseña',
      'currentPassword': 'Contraseña Actual',
      'newPassword': 'Nueva Contraseña',
      'confirmNewPassword': 'Confirmar Nueva Contraseña',

      'updateImage': 'Actualizar Imagen',
      'fullName': 'Nombre Completo',
      'address': 'DIRECCIÓN',
      //Punch Screen
      'selectWorkSite': 'Seleccionar sitio',
      'searchWorkSites': 'Buscar sitio',
      'unnamedSite': 'Sitio sin nombre',
      'noAddress': 'Sin dirección',
      'punchIn': 'Ingresar',
      'punchOut': 'Salga',
      'punch': 'Registro',
      'home': 'La casa',
      'logout': 'Cerrar sesión',
      'finance': 'Finanzas',
      'workedHours': 'Horas trabajadas:',


      'productivity': 'Productividad',
      'attendance': 'Asistencia',
      'hours': 'Horas',
      'overtime': 'Horas extras',
      'missedHours': 'Horas perdidas',
      'period': 'Período',
      'workerPayroll': 'Nómina del trabajador',
      'hourlyRate': 'Tarifa hora',
      'gross': 'Bruto',
      'totalTaxes': 'Impuestos',
      'netTotal': 'Total neto',
      'workerFinancialStatistics': 'Estadísticas financieras del trabajador',
      'earningsDynamics': 'Dinámica de ganancias',
      'noDataAvailable': 'No hay datos disponibles',
      'employee': 'Empleado',
      'refresh': 'Refrescar',

      "finance.title": "Finanzas",
      "finance.downloadPdfReport": "Generando informe PDF...",
      "finance.reportDownloadedSuccessfully": "Informe descargado con éxito",
      "finance.errorDownloadingReport": "Error al descargar informe",
      "finance.errorLoadingData": "Error al cargar datos",
      "finance.downloadTooltip": "Descargar Informe PDF",
      "finance.shareTooltip": "Compartir Resumen",
      "finance.shareTitle": "Resumen Financiero",
      "finance.totalHours": "Horas Totales",
      "finance.totalGrossPay": "Pago Bruto Total",
      "finance.totalNetPay": "Pago Neto Total",
      "finance.totalTaxes": "Impuestos Totales",
      "finance.previous": "Anterior",
      "finance.next": "Siguiente",
      "finance.weekPeriod": "Período Semanal",
      "finance.hours": "Horas",
      "finance.gross": "Bruto",
      "finance.net": "Neto",
      "finance.day": "Día",
      "finance.noDataForPeriod": "No hay datos para este período",
      "finance.refresh": "Actualizar",
      "finance.totals": "Totales",
      // Employee Screen
      "employee.title": "Empleados",
      "employee.subtitle": "Seleccione un sitio de trabajo para ver detalles",
      "employee.searchHint": "Buscar sitios de trabajo...",
      "employee.error": "Error al cargar sitios de trabajo",
      "employee.retry": "Reintentar",
      'contactInformation' :'Información del contacto',


      // Worksite Employees Screen
      "worksiteEmployees.title": "Empleados",
      "worksiteEmployees.subtitle": "Sitio de trabajo #",
      "worksiteEmployees.refresh": "Actualizar",
      "worksiteEmployees.loading": "Cargando empleados...",
      "worksiteEmployees.emptyTitle": "Nadie ha registrado entrada aún",
      "worksiteEmployees.emptyDescription": "Los empleados que hayan registrado entrada en este sitio aparecerán aquí.",
      "worksiteEmployees.errorTitle": "Algo salió mal",
      "worksiteEmployees.errorDescription": "Error al cargar datos. Verifique su conexión e intente nuevamente.",
      "worksiteEmployees.tryAgain": "Intentar de nuevo",
      "worksiteEmployees.deleteCheckIn": "Eliminar registro",
      "worksiteEmployees.updateTime": "Actualizar hora",
      "worksiteEmployees.checkInTime": "Hora de entrada:",
      "worksiteEmployees.confirmTitle": "Confirmación",
      "worksiteEmployees.confirmDeleteTime": "¿Está seguro de que desea eliminar la hora de entrada?",
      "worksiteEmployees.cancel": "Cancelar",
      "worksiteEmployees.delete": "Eliminar",
      "worksiteEmployees.timeUpdated": "Hora actualizada:",
      "worksiteEmployees.timeUpdatedSuccess": "Hora actualizada exitosamente",
      "worksiteEmployees.timeDeleted": "Hora de entrada eliminada exitosamente",
      "worksiteEmployees.error": "Error:",
      "worksiteEmployees.enterTime": "Introducir hora",
      "worksiteEmployees.todayDate": "La fecha de hoy se utilizará automáticamente",
      "worksiteEmployees.ready": "Listo",
      "worksiteEmployees.enterValidTime": "Por favor, ingrese una hora válida",
      'weeklyProgress' : 'Progreso semanal'

    },

    'ru': {
      // Notifications
      'notifications.title': 'Уведомления',
      'notifications.clearAll': 'Очистить все',
      'notifications.noNotifications': 'Нет входящих уведомлений',

      // Daily Notifications
      'dailyPunchIn.title': 'Не забудьте отметиться при входе!',
      'dailyPunchIn.body': 'Откройте приложение и отметьтесь при входе!',
      'dailyPunchOut.title': 'Не забудьте отметиться при выходе!',
      'dailyPunchOut.body': 'Откройте приложение и отметьтесь при выходе!',
      'weeklyHoursCheck.title': 'Проверьте, что отработанные часы указаны корректно!',
      'weeklyHoursCheck.body': 'Убедитесь, что отработанные часы указаны корректно! Если у вас возникли проблемы, свяжитесь с вашим менеджером и предоставьте ему информацию!',

      // Main Menu
      'viewDetails': 'Подробнее',
      'lastPunch': 'Последняя отметка',

      // Settings - General
      'settings': 'Настройки',
      'profile': 'Профиль',
      'phoneNumber': 'Номер телефона',
      'email': 'Эл. почта',
      'password': 'Пароль',
      'preferences': 'Предпочтения',
      'timeFormat': 'Формат времени',
      'theme': 'Тема',
      'dark': 'Тёмная',
      'white': 'Светлая',
      'language': 'Язык',
      'english': 'Английский',
      'spanish': 'Испанский',
      'russian': 'Русский',
      'cancel': 'Отмена',
      'save': 'Сохранить',

      // Settings - Phone
      'editPhoneNumber': 'Изменить номер телефона',
      'currentPhoneNumber': 'Текущий номер телефона',
      'currentPhoneNumberHint': 'Введите текущий номер телефона',
      'newPhoneNumber': 'Новый номер телефона',
      'newPhoneNumberHint': 'Введите новый номер телефона',
      'confirmNewPhoneNumber': 'Подтвердите новый номер телефона',
      'confirmNewPhoneNumberHint': 'Подтвердите новый номер телефона',
      'phoneNumbersDoNotMatch': 'Номера телефонов не совпадают',
      'phoneNumberUpdated': 'Номер телефона успешно обновлен',

      // Settings - Email
      'editEmail': 'Изменить эл. почту',
      'currentEmail': 'Текущая эл. почта',
      'currentEmailHint': 'Введите текущую эл. почту',
      'new': 'Новый',
      'сonfirmNew': 'Подтвердить новый',
      'emailsDoNotMatch': 'Адреса эл. почты не совпадают',
      'emailUpdated': 'Эл. почта успешно обновлена',

      // Settings - Password
      'changePassword': 'Изменить пароль',
      'currentPassword': 'Текущий пароль',
      'newPassword': 'Новый пароль',
      'confirmNewPassword': 'Подтвердите новый пароль',

      'updateImage': 'Обновить фото',
      'fullName': 'Полное Имя',
      'address': 'Адрес',

      //Punch Screen
      'selectWorkSite': 'Выбрать рабочую площадку!',
      'searchWorkSites': 'Найти рабочую площадку',
      'unnamedSite': 'Рабочая площадка без имени!',
      'noAddress': 'Нет Адреса',
      'punchIn': 'Вход в',
      'punchOut': 'Выход на',
      'punch': 'Отметка',
      'home': 'Домой',
      'logout': 'Выход',
      'finance': 'Финансы',
      'workedHours': 'Отработаные Часы:',


      // View Details Screen
      'productivity': 'Продуктивность',
      'attendance': 'Посещаемость',
      'hours': 'Часы',
      'overtime': 'Сверхурочные',
      'missedHours': 'Пропущенные часы',
      'period': 'Период',
      'workerPayroll': 'Зарплата работника',
      'hourlyRate': 'Ставка/час',
      'gross': 'Валовая',
      'totalTaxes': 'Налоги',
      'netTotal': 'Чистыми',
      'workerFinancialStatistics': 'Финансовая статистика работника',
      'earningsDynamics': 'Динамика заработка',
      'noDataAvailable': 'Данные отсутствуют',
      'employee': 'Работнки',
      'refresh': 'Обновить',


      "finance.title": "Финансы",
      "finance.downloadPdfReport": "Создание PDF отчета...",
      "finance.reportDownloadedSuccessfully": "Отчет успешно загружен",
      "finance.errorDownloadingReport": "Ошибка при загрузке отчета",
      "finance.errorLoadingData": "Ошибка загрузки данных",
      "finance.downloadTooltip": "Скачать PDF отчет",
      "finance.shareTooltip": "Поделиться итогами",
      "finance.shareTitle": "Финансовая сводка",
      "finance.totalHours": "Всего часов",
      "finance.totalGrossPay": "Общая зарплата брутто",
      "finance.totalNetPay": "Общая зарплата нетто",
      "finance.totalTaxes": "Всего налогов",
      "finance.previous": "Назад",
      "finance.next": "Вперед",
      "finance.weekPeriod": "Период недели",
      "finance.hours": "Часы",
      "finance.gross": "Брутто",
      "finance.net": "Нетто",
      "finance.day": "День",
      "finance.noDataForPeriod": "Нет данных за этот период",
      "finance.refresh": "Обновить",
      "finance.totals": "Итого",


      // Employee Screen
      "employee.title": "Сотрудники",
      "employee.subtitle": "Выберите рабочий объект для подробностей",
      "employee.searchHint": "Поиск рабочих объектов...",
      "employee.error": "Не удалось загрузить рабочие объекты",
      "employee.retry": "Повторить",

      // Worksite Employees Screen
      "worksiteEmployees.title": "Сотрудники",
      "worksiteEmployees.subtitle": "Рабочий объект #",
      "worksiteEmployees.refresh": "Обновить",
      "worksiteEmployees.loading": "Загрузка сотрудников...",
      "worksiteEmployees.emptyTitle": "Пока никто не отметился",
      "worksiteEmployees.emptyDescription": "Сотрудники, отметившиеся на этом объекте, будут отображаться здесь.",
      "worksiteEmployees.errorTitle": "Что-то пошло не так",
      "worksiteEmployees.errorDescription": "Не удалось загрузить данные. Проверьте подключение и попробуйте снова.",
      "worksiteEmployees.tryAgain": "Попробовать снова",
      "worksiteEmployees.deleteCheckIn": "Удалить отметку",
      "worksiteEmployees.updateTime": "Обновить время",
      "worksiteEmployees.checkInTime": "Время прихода:",
      "worksiteEmployees.confirmTitle": "Подтверждение",
      "worksiteEmployees.confirmDeleteTime": "Вы уверены, что хотите удалить время прихода?",
      "worksiteEmployees.cancel": "Отмена",
      "worksiteEmployees.delete": "Удалить",
      "worksiteEmployees.timeUpdated": "Время обновлено:",
      "worksiteEmployees.timeUpdatedSuccess": "Время успешно обновлено",
      "worksiteEmployees.timeDeleted": "Время прихода успешно удалено",
      "worksiteEmployees.error": "Ошибка:",
      "worksiteEmployees.enterTime": "Введите время",
      "worksiteEmployees.todayDate": "Сегодняшняя дата будет использована автоматически",
      "worksiteEmployees.ready": "Готово",
      "worksiteEmployees.enterValidTime": "Пожалуйста, введите корректное время",

      'contactInformation' :'Контактная Информация',
       'weeklyProgress' : 'Прогрес за неделю'

}
  };

  String get(String key) {
    return _localizedValues[languageCode]?[key] ??
        _localizedValues['en']?[key] ??
        key;
  }
}